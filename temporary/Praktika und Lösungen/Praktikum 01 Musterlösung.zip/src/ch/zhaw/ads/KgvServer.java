package ch.zhaw.ads;

/**
 * KgvServer -- Praktikum Experimentierkasten -- SW3
 *
 * @author Simon Aebersold
 * @version 1.0 -- Geruest fuer irgendeinen Server
 */
public class KgvServer implements CommandExecutor {
    int ggt(int a, int b) {
        if (a > b) return ggt(a - b, b);
        else if (a < b) return ggt(a, b - a);
        else return a;
    }

    public int kgv(int a, int b) {
        return a * b / ggt(a, b);
    }

    //----- Dies implementiert das CommandExecutor Interface.
    @Override
    public String execute(String command) {
        String[] numbers = command.split("[, ]");
        int a = Integer.parseInt(numbers[0]);
        int b = Integer.parseInt(numbers[1]);
        return "kgV von " + a + " und " + b +
                " ist: " + kgv(a, b) + "\n";
    }
}
