package ch.zhaw.ads;

import java.util.regex.*;

public class WellformedXmlServer implements CommandExecutor {
    private final static String EOT = ""; // end of text
    private static final Pattern pat = Pattern.compile("<[^\\?!][^>]*[^/]>|<.>");
    private Matcher matcher;

    private String getNextToken() {
        if (matcher.find()) {
            // strip attributes
            return matcher.group().split("[ >]")[0]+">";
        }	else {
            return EOT;
        }
    }
    public boolean checkWellformed(String content) {
        return execute(content).contains("OK");
    }

    public String execute(String command) {
        Stack stack = new ListStack();
        matcher = pat.matcher(command);

        String token = getNextToken();
        while (!EOT.equals(token)) {
            // opening token?
            if (token.indexOf('/') < 0 ) {
                stack.push(token);
            }
            // closing token?
            else if (token.indexOf('/') > 0) {
                if (stack.isEmpty()) return token +" is not opened\n";
                String token1 = (String)stack.pop();
                // token correspond?
                if (!token1.equals(token.replace("/", "")))
                    return token1 + " does not match\n";
            }
            token = getNextToken();
        }
        if (stack.isEmpty())
            return "OK\n";
        else
            return "token \""+stack.pop()+"\" not closed\n";
    }
}