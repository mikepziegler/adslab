package ch.zhaw.ads;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class RankingListServer implements CommandExecutor {
    public List<Competitor> createList(String rankingText) {
        List<Competitor> competitorList = new LinkedList<>();
        String[] lines = rankingText.split("\n");
        for (String line : lines) {
            String name = line.split(";")[0];
            String time = line.split(";")[1];
            competitorList.add(new Competitor(0, name,  time));
        }
        return competitorList;
    }

    public String createSortedText(List<Competitor> competitorList) {
        Collections.sort(competitorList);
        StringBuilder sb = new StringBuilder();
        int rank = 1;
        for (Competitor c : competitorList) {
            c.setRank(rank);
            rank++;
        }
        for (Competitor c : competitorList) {
            sb.append(c).append("\n");
        }
        return sb.toString();
    }

    public String createNameList(List<Competitor> competitorList) {
        competitorList.sort(new AlphaComparatorCompetitor());
        StringBuilder sb = new StringBuilder();
        for (Competitor c : competitorList) {
            sb.append(c).append("\n");
        }
        return sb.toString();
    }

    public String execute(String rankingList) {
        List<Competitor> competitorList = createList(rankingList);
        return "Rangliste\n" + createSortedText(competitorList) + "\n\nNamensliste\n" + createNameList(competitorList);
    }
}