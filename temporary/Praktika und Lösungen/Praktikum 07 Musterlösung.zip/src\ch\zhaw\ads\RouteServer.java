package ch.zhaw.ads;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.StringTokenizer;

public class RouteServer implements CommandExecutor {
    /**
    build the graph given a text file with the topology
    */
    public Graph<DijkstraNode, Edge> createGraph(String topo) throws Exception {
        Graph<DijkstraNode, Edge> graph = new AdjListGraph<>(DijkstraNode.class, Edge.class);
        StringTokenizer tok = new StringTokenizer(topo);
        while (tok.hasMoreTokens()) {
            String from = tok.nextToken();
            String to = tok.nextToken();
            int dist = Integer.parseInt(tok.nextToken());
            try {
                graph.addEdge(from, to, dist);
                graph.addEdge(to, from, dist);
            } catch (Throwable t) {
                throw new Exception(t);
            }

        }
        return graph;
    }

    private void log(String msg) {
        //System.out.println(msg);
    }

    /**
    apply the dijkstra algorithm
    */
    public void dijkstraRoute(Graph<DijkstraNode, Edge> graph, String from, String to) {
        Queue<DijkstraNode> pq = new java.util.PriorityQueue<>();
        DijkstraNode town = graph.findNode(from);
        DijkstraNode goal = graph.findNode(to);
        town.setDist(0);
        town.setMark(true);
        pq.add(town);
        while (!pq.isEmpty()) {
            DijkstraNode currentTown = pq.remove();
            log("dequeue:" + currentTown.getName() + " " + currentTown.getDist());
            currentTown.setMark(true);
            if (currentTown == goal) {
                return;
            }
            for (Edge road: currentTown.getEdges()) {
                town = (DijkstraNode) road.getDest();
                if (!town.getMark()) {
                    double dist = currentTown.getDist() + road.getWeight();
                    if ((town.getPrev() == null) || (dist < town.getDist())) {
                        town.setDist(dist);
                        town.setPrev(currentTown);
                        log("enqueue:" + town.getName() + " " + town.getDist());
                        pq.add(town);
                    }
                }
            }
        }
    }

    /**
    find the route in the graph after applied dijkstra
    the route should be returned with the start town first
    */
    public List<DijkstraNode> getRoute(Graph<DijkstraNode, Edge> graph, String to) {
        List<DijkstraNode> route = new LinkedList<>();
        DijkstraNode town = graph.findNode(to);
        do {
            route.add(0, town);
            town = town.getPrev();
        } while (town != null);
        return route;
    }

    public String execute(String topo) throws Exception {
        Graph<DijkstraNode, Edge> graph = createGraph(topo);
        dijkstraRoute(graph, "Winterthur", "Lugano");
        List<DijkstraNode> route = getRoute(graph, "Lugano");
        // generate result string
        StringBuilder builder = new StringBuilder();
        for (DijkstraNode rt : route) builder.append(rt).append("\n");
        return builder.toString();
    }

    public static void main(String[] args)throws Exception {
        String swiss = "Winterthur Zürich 25\n" +
                    "Zürich Bern 126\n" +
                    "Zürich Genf 277\n" +
                    "Zürich Luzern 54\n" +
                    "Zürich Chur 121\n" +
                    "Zürich Berikon 16\n" +
                    "Bern Genf 155\n" +
                    "Genf Lugano 363\n" +
                    "Lugano Luzern 206\n" +
                    "Lugano Chur 152\n" +
                    "Chur Luzern 146\n" +
                    "Luzern Bern 97\n" +
                    "Bern Berikon 102\n" +
                    "Luzern Berikon 41\n";
        RouteServer server = new RouteServer();
        System.out.println(server.execute(swiss));
    }
}
